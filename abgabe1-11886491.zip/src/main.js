import Renderer from './renderer'
import {
  TextureLoader,
  Mesh,
  MeshBasicMaterial,
  CircleGeometry,
  Line,
  BackSide,
  LineBasicMaterial,
  Vector3,
  PointLight,
  AmbientLight,
  MeshPhongMaterial,
  RingGeometry,
  SphereGeometry,
  LineLoop,
  DoubleSide,
  ShaderMaterial
} from 'three'
import ringVS from './shaders/saturn_ring.vs.glsl'
import ringFS from './shaders/saturn_ring.fs.glsl'

export default class SolarSystem extends Renderer {
  constructor() {
    super()
    this.params = {
      segment: 64,
      universe: {
        radius: 15000,
        texture: './assets/universe.jpg',
      },
      sun: {
        radius: 50,
        distance: 0,
        selfRotate: 0.001,
        revolution: 0,
        texture: './assets/sun.jpg',
        light: {
          color: 0xffffff,
          intensity: 1,
          ambientColor: 0x090909,
          ambientIntensity: 1,
        }
      },
      planets: {
        mercury: {
          radius: 4,
          distance: 76,
          selfRotate: 0.005,
          revolution: 0.00413,
          texture: './assets/mercury.jpg',
        },
        venus: {
          radius: 8,
          distance: 144,
          selfRotate: 0.01,
          revolution: 0.0016,
          texture: './assets/venus.jpg',
        },
        earth: {
          radius: 9,
          distance: 200,
          selfRotate: 0.01,
          revolution: 0.00098,
          texture: './assets/earth.jpg',
          moon: {
            radius: 0.6,
            distance: 15, // distance to the earth
            selfRotate: 0.005,
            revolution: 0.12, // revolution around the earth
            angle: 0,
            texture: './assets/moon.jpg',
          },
        },
        mars: {
          radius: 5,
          distance: 304,
          selfRotate: 0.01,
          revolution: 0.0052,
          texture: './assets/mars.jpg',
        },
        jupiter: {
          radius: 51,
          distance: 1040,
          selfRotate: 0.007,
          revolution: 0.0017,
          texture: './assets/jupiter.jpg',
        },
        saturn: {
          radius: 42,
          distance: 1970,
          selfRotate: 0.01,
          revolution: 0.0011,
          texture: './assets/saturn.jpg',
          ring: {
            texture: './assets/saturn_ring.png',
            innerRadius: 45,
            outerRadius: 80,
            xRotate: Math.PI / 3,
            angle: 0
          }
        },
        uranus: {
          radius: 18.2,
          distance: 3843,
          selfRotate: 0.01,
          revolution: 0.0008,
          texture: './assets/uranus.jpg',
        },
        neptune: {
          radius: 17.6,
          distance: 6011,
          selfRotate: 0.01,
          revolution: 0.0006,
          texture: './assets/neptune.jpg',
        }
      },
      orbit: {
        color: 0xeeeeee,
        transparent: true,
        opacity: 0.2,
      }
    }
    this.sun = null
    this.planets = {
      mercury: {
        planet: null,
        orbit: null,
        revolution: 0,
      },
      venus: {
        planet: null,
        orbit: null,
        revolution: 0,
      },
      earth: {
        planet: null,
        orbit: null,
        revolution: 0,
        moon: {
          planet: null,
          orbit: null,
          revolution: 0,
        }
      },
      mars: {
        planet: null,
        orbit: null,
        revolution: 0,
      },
      jupiter: {
        planet: null,
        orbit: null,
        revolution: 0,
      },
      saturn: {
        planet: null,
        orbit: null,
        revolution: 0,
        ring: null
      },
      uranus: {
        planet: null,
        orbit: null,
        revolution: 0,
      },
      neptune: {
        planet: null,
        orbit: null,
        revolution: 0,
      }
    }
    this.loadAssets().then(() => this.setup())
  }
  async loadAssets() {
    const loader = (T, url) => {
      return new Promise(resolve => new T().load(url, resolve))
    }
    const promises = [
      loader(TextureLoader, this.params.universe.texture),
      loader(TextureLoader, this.params.sun.texture),
      loader(TextureLoader, this.params.planets.mercury.texture),
      loader(TextureLoader, this.params.planets.venus.texture),
      loader(TextureLoader, this.params.planets.earth.texture),
      loader(TextureLoader, this.params.planets.earth.moon.texture),
      loader(TextureLoader, this.params.planets.mars.texture),
      loader(TextureLoader, this.params.planets.jupiter.texture),
      loader(TextureLoader, this.params.planets.saturn.texture),
      loader(TextureLoader, this.params.planets.saturn.ring.texture),
      loader(TextureLoader, this.params.planets.uranus.texture),
      loader(TextureLoader, this.params.planets.neptune.texture),
    ]
    const assets = await Promise.all(promises)
    this.params.universe.texture = assets[0]
    this.params.sun.texture = assets[1]
    this.params.planets.mercury.texture = assets[2]
    this.params.planets.venus.texture = assets[3]
    this.params.planets.earth.texture = assets[4]
    this.params.planets.earth.moon.texture = assets[5]
    this.params.planets.mars.texture = assets[6]
    this.params.planets.jupiter.texture = assets[7]
    this.params.planets.saturn.texture = assets[8]
    this.params.planets.saturn.ring.texture = assets[9]
    this.params.planets.uranus.texture = assets[10]
    this.params.planets.neptune.texture = assets[11]
  }
  setup() {
    // TODO: 1. create a starry sky background 
    this.params.universe.texture.anisotropy = 16; //reduce blurring
    const universe = new Mesh( //3D object universe
      new SphereGeometry(
        this.params.universe.radius,
        this.params.segment,
        this.params.segment),
      new MeshBasicMaterial({
        map: this.params.universe.texture,
        side: BackSide
      })
    );
    this.scene.add(universe); //added to scene graph

    // TODO: 2. create a sun as the center of the solar system
    this.params.sun.texture.anisotropy = 16; //reduce blurring
    this.sun = new Mesh(
      new SphereGeometry( //sun geometry
        this.params.sun.radius,
        this.params.segment,
        this.params.segment),
      new MeshBasicMaterial({ //sun material
        map: this.params.sun.texture //mapping of sun texture
      }));
    this.scene.add(this.sun); //added to scene graph

    // TODO: 3. create a light to simulate the sun light
    this.scene.add(new PointLight( //point light
      this.params.sun.light.color,
      this.params.sun.light.intensity));

    this.scene.add(new AmbientLight( //ambient light
      this.params.sun.light.ambientColor,
      this.params.sun.light.ambientIntensity));

    // TODO: 4. create the eight planets using provided textures, and
    //          move them with a given distance to the sun 
    //mercury
    this.params.planets.mercury.texture.anisotropy = 16;
    this.planets.mercury.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.mercury.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.mercury.texture
      }));
    this.planets.mercury.planet.translateX(this.params.planets.mercury.distance); //distance from the sun
    this.scene.add(this.planets.mercury.planet);

    //venus
    this.params.planets.mercury.texture.anisotropy = 16;
    this.planets.venus.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.venus.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.venus.texture
      }));
    this.planets.venus.planet.translateX(this.params.planets.venus.distance); //distance from the sun
    this.scene.add(this.planets.venus.planet);

    //earth
    this.params.planets.earth.texture.anisotropy = 16;
    this.planets.earth.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.earth.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.earth.texture
      }));
    this.planets.earth.planet.translateX(this.params.planets.earth.distance); //distance from the sun
    this.scene.add(this.planets.earth.planet);

    //mars
    this.params.planets.mars.texture.anisotropy = 16;
    this.planets.mars.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.mars.radius,
        this.params.segment,
        this.params.segment
      ), new MeshPhongMaterial({
        map: this.params.planets.mars.texture
      }));
    this.planets.mars.planet.translateX(this.params.planets.mars.distance); //distance from the sun
    this.scene.add(this.planets.mars.planet);

    //jupiter
    this.params.planets.jupiter.texture.anisotropy = 16;
    this.planets.jupiter.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.jupiter.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.jupiter.texture
      }));
    this.planets.jupiter.planet.translateX(this.params.planets.jupiter.distance); //distance from the sun
    this.scene.add(this.planets.jupiter.planet);

    //saturn
    this.params.planets.saturn.texture.anisotropy = 16;
    this.planets.saturn.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.saturn.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.saturn.texture
      }));
    this.planets.saturn.planet.translateX(this.params.planets.saturn.distance); //distance from the sun
    this.scene.add(this.planets.saturn.planet);

    //uranus
    this.params.planets.uranus.texture.anisotropy = 16;
    this.planets.uranus.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.uranus.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.uranus.texture
      }));
    this.planets.uranus.planet.translateX(this.params.planets.uranus.distance); //distance from the sun
    this.scene.add(this.planets.uranus.planet);

    //neptune
    this.params.planets.neptune.texture.anisotropy = 16;
    this.planets.neptune.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.neptune.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.neptune.texture
      }));
    this.planets.neptune.planet.translateX(this.params.planets.neptune.distance); //distance from the sun
    this.scene.add(this.planets.neptune.planet);

    // TODO: 5. draw a (circular) orbit for each planet
    // orbit geometry for all planets
    const orbitMercury = new CircleGeometry(
      this.params.planets.mercury.distance,
      this.params.segment
    );
    orbitMercury.vertices.shift(); //closed circle

    const orbitVenus = new CircleGeometry(
      this.params.planets.venus.distance,
      this.params.segment
    );
    orbitVenus.vertices.shift(); //closed circle

    const orbitEarth = new CircleGeometry(
      this.params.planets.earth.distance,
      this.params.segment
    );
    orbitEarth.vertices.shift(); //closed circle

    const orbitMars = new CircleGeometry(
      this.params.planets.mars.distance,
      this.params.segment
    );
    orbitMars.vertices.shift(); //closed circle

    const orbitJupiter = new CircleGeometry(
      this.params.planets.jupiter.distance,
      this.params.segment
    );
    orbitJupiter.vertices.shift(); //closed circle

    const orbitSaturn = new CircleGeometry(
      this.params.planets.saturn.distance,
      this.params.segment
    );
    orbitSaturn.vertices.shift(); //closed circle

    const orbitUranus = new CircleGeometry(
      this.params.planets.uranus.distance,
      this.params.segment
    );
    orbitUranus.vertices.shift(); //closed circle

    const orbitNeptune = new CircleGeometry(
      this.params.planets.neptune.distance,
      this.params.segment
    );
    orbitNeptune.vertices.shift(); //closed circle

    //material for all orbits
    const orbitMaterial = new LineBasicMaterial(this.params.orbit);

    //mercury orbit
    this.planets.mercury.orbit = new LineLoop(orbitMercury, orbitMaterial);
    this.planets.mercury.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.mercury.orbit.attach(this.planets.mercury.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.mercury.orbit);

    //venus orbit
    this.planets.venus.orbit = new LineLoop(orbitVenus, orbitMaterial);
    this.planets.venus.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.venus.orbit.attach(this.planets.venus.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.venus.orbit);

    //earth orbit
    this.planets.earth.orbit = new LineLoop(orbitEarth, orbitMaterial);
    this.planets.earth.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.earth.orbit.attach(this.planets.earth.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.earth.orbit);

    //mars orbit
    this.planets.mars.orbit = new LineLoop(orbitMars, orbitMaterial);
    this.planets.mars.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.mars.orbit.attach(this.planets.mars.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.mars.orbit);

    //jupiter orbit
    this.planets.jupiter.orbit = new LineLoop(orbitJupiter, orbitMaterial);
    this.planets.jupiter.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.jupiter.orbit.attach(this.planets.jupiter.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.jupiter.orbit);

    //saturn orbit
    this.planets.saturn.orbit = new LineLoop(orbitSaturn, orbitMaterial);
    this.planets.saturn.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.saturn.orbit.attach(this.planets.saturn.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.saturn.orbit);

    //uranus orbit
    this.planets.uranus.orbit = new LineLoop(orbitUranus, orbitMaterial);
    this.planets.uranus.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.uranus.orbit.attach(this.planets.uranus.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.uranus.orbit);

    //neptune orbit
    this.planets.neptune.orbit = new LineLoop(orbitNeptune, orbitMaterial);
    this.planets.neptune.orbit.rotateX(1.5708); //rotate 90 degrees
    this.planets.neptune.orbit.attach(this.planets.neptune.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.neptune.orbit);

    // TODO: 6. create the moon and its orbit 
    //moon
    this.planets.earth.moon.planet = new Mesh(
      new SphereGeometry(
        this.params.planets.earth.moon.radius,
        this.params.segment,
        this.params.segment),
      new MeshPhongMaterial({
        map: this.params.planets.earth.moon.texture
      }));
    //distance to sun + to earth
    this.planets.earth.moon.planet.translateX(this.params.planets.earth.moon.distance + this.params.planets.earth.distance);
    this.scene.add(this.planets.earth.moon.planet);

    //moon orbit
    const orbitMoon = new CircleGeometry(
      this.params.planets.earth.moon.distance,
      this.params.segment
    );
    orbitMoon.vertices.shift();

    this.planets.earth.moon.orbit = new LineLoop(orbitMoon, orbitMaterial);
    this.planets.earth.moon.orbit.rotateX(1.5708); // rotate 90 degrees
    this.planets.earth.moon.orbit.translateX(this.params.planets.earth.distance); //distance to sun
    this.planets.earth.moon.orbit.attach(this.planets.earth.moon.planet); //attach planet to orbit for orbiting
    this.scene.add(this.planets.earth.moon.orbit);

    // TODO: 7. create the saturn ring and apply corresponing texture
    //          mapping with a customized fragment shader
    this.planets.saturn.ring = new Mesh( //3D ring
      new RingGeometry(
        this.params.planets.saturn.ring.innerRadius,
        this.params.planets.saturn.ring.outerRadius,
        30),
      new ShaderMaterial({
        side: DoubleSide, //rendered on both sides
        uniforms: { //uniforms for shader
          ringTexture: {
            value: this.params.planets.saturn.ring.texture
          },
          innerRadius: {
            value: this.params.planets.saturn.ring.innerRadius
          },
          outerRadius: {
            value: this.params.planets.saturn.ring.outerRadius
          }
        },
        vertexShader: ringVS, //custom vertex shader
        fragmentShader: ringFS //custom fragment shader
      }));
    this.planets.saturn.ring.rotateX(this.params.planets.saturn.ring.xRotate); //rotated
    this.planets.saturn.ring.translateX(this.params.planets.saturn.distance); //around saturn
    this.scene.add(this.planets.saturn.ring); //added to scene graph

    this.render()
  }
  update() {
    // TODO: 8. add self rotation to the sun
    //sun self-rotation
    this.sun.rotation.y += this.params.sun.selfRotate;

     // TODO: 9. add self rotation to the eight planets
    this.planets.mercury.planet.rotation.y += this.params.planets.mercury.selfRotate;
    this.planets.venus.planet.rotation.y += this.params.planets.venus.selfRotate;
    this.planets.earth.planet.rotation.y += this.params.planets.earth.selfRotate;
    this.planets.mars.planet.rotation.y += this.params.planets.mars.selfRotate;
    this.planets.jupiter.planet.rotation.y += this.params.planets.jupiter.selfRotate;
    this.planets.uranus.planet.rotation.y += this.params.planets.uranus.selfRotate;
    this.planets.saturn.planet.rotation.y += this.params.planets.saturn.selfRotate;
    this.planets.neptune.planet.rotation.y += this.params.planets.neptune.selfRotate;

    // TODO: 10. add revolution to the eight planets
    //rotating orbit so planet moves
    this.planets.mercury.orbit.rotation.z -= this.params.planets.mercury.revolution;
    this.planets.venus.orbit.rotation.z -= this.params.planets.venus.revolution;
    this.planets.earth.orbit.rotation.z -= this.params.planets.earth.revolution;
    this.planets.mars.orbit.rotation.z -= this.params.planets.mars.revolution;
    this.planets.jupiter.orbit.rotation.z -= this.params.planets.jupiter.revolution;
    this.planets.uranus.orbit.rotation.z -= this.params.planets.uranus.revolution;
    this.planets.neptune.orbit.rotation.z -= this.params.planets.neptune.revolution;
    this.planets.saturn.orbit.rotation.z -= this.params.planets.saturn.revolution;

    // TODO: 11. add self rotation and revolution to the moon
    //moon self-rotation
    this.planets.earth.moon.planet.rotation.y += this.params.planets.earth.moon.selfRotate;
    //moon orbiting earth
    this.planets.earth.moon.orbit.rotation.z -= this.params.planets.earth.moon.revolution;

    //moving moon + orbit with earth
    this.params.planets.earth.moon.angle -= this.params.planets.earth.revolution;
    this.planets.earth.moon.orbit.position.x = Math.cos(this.params.planets.earth.moon.angle) * this.params.planets.earth.distance;
    this.planets.earth.moon.orbit.position.z = Math.sin(this.params.planets.earth.moon.angle) * this.params.planets.earth.distance;

    // TODO: 12. move the saturn ring while saturn is moving
    this.params.planets.saturn.ring.angle -= this.params.planets.saturn.revolution;
    this.planets.saturn.ring.position.x = Math.cos(this.params.planets.saturn.ring.angle) * this.params.planets.saturn.distance;
    this.planets.saturn.ring.position.z = Math.sin(this.params.planets.saturn.ring.angle) * this.params.planets.saturn.distance;
  }
}

new SolarSystem()